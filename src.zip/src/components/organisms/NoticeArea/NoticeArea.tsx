import GridLow from "@/components/molecules/GridLow/GridLow";
import NoticeCard from "@/components/molecules/NoticeCard/NoticeCard";

type Props = {
  children?: React.ReactNode;
};

const NoticeArea = ({ children }: Props) => {
  return (
    <GridLow grid="3">
      <NoticeCard />
      <NoticeCard />
      <NoticeCard />
    </GridLow>
  );
};

export default NoticeArea;
