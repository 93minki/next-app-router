import NavItem from "@/components/atoms/NavItem/NavItem";
import GridLow from "@/components/molecules/GridLow/GridLow";
import TestFolder from "@/components/molecules/TestFolder/TestFolder";

const TestFolderArea = () => {
  return (
    <div>
      {/* <MoreButton className="text-right pt-2 pr-4">&gt; 더보기</MoreButton> */}
      <NavItem href="/">{"> 더보기"}</NavItem>
      <GridLow grid="6">
        <TestFolder />
        <TestFolder />
        <TestFolder />
      </GridLow>
    </div>
  );
};

export default TestFolderArea;
