"use client";

import React from "react";
import TestList from "./TestArea";
import CheckButton from "@/components/atoms/CheckButton/CheckButton";
import SearchBox from "@/components/molecules/SearchBox/SearchBox";
import FlexLow from "@/components/molecules/FlexLow/FlexLow";
import GridLow from "@/components/molecules/GridLow/GridLow";
import Text from "@/components/atoms/Text/Text";
import Input from "@/components/atoms/Input/Input";

export default function TestArea() {
  return (
    <div className="flex flex-col gap-2 bg-slate-400">
      {/* 탭 */}
      <FlexLow>
        <CheckButton checked>전체</CheckButton>
        <CheckButton>내가 만든 시험지</CheckButton>
        <CheckButton>구매한 시험지</CheckButton>
      </FlexLow>
      <FlexLow>
        <CheckButton checked>전체</CheckButton>
        <CheckButton>초</CheckButton>
        <CheckButton>중</CheckButton>
        <CheckButton>고</CheckButton>

        <SearchBox />
      </FlexLow>

      {/* 시험지목록 */}
      <GridLow grid="3">
        <Text bold="semibold">어쩌고</Text>
        <Text bold="semibold">저쩌고</Text>
        <Text bold="semibold">왈랄랄</Text>
      </GridLow>

      <GridLow grid="3">
        <Input type="checkbox" />
        <Text>시험지명</Text>
        <Text>생성일</Text>
      </GridLow>

      <GridLow grid="3">
        <Input type="checkbox" />
        <Text>시험지명</Text>
        <Text>생성일</Text>
      </GridLow>

      <GridLow grid="3">
        <Input type="checkbox" />
        <Text>시험지명</Text>
        <Text>생성일</Text>
      </GridLow>
    </div>
  );
}
