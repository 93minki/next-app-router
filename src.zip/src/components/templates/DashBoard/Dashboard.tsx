import { Suspense } from "react";

type Props = {
  sideArea: React.ReactNode;
  noticeArea: React.ReactNode;
  testFolderArea: React.ReactNode;
  testArea: React.ReactNode;
};

const DashBoardTemplate = ({
  sideArea,
  noticeArea,
  testFolderArea,
  testArea,
}: Props) => {
  return (
    <div className=" md:flex justify-between my-5 gap-5 ">
      <aside className="md:w-1/4">{sideArea}</aside>
      <main className="flex flex-col grow gap-5">
        <section>{noticeArea}</section>
        <section>{testFolderArea}</section>
        <section>{testArea}</section>
      </main>
    </div>
  );
};
export default DashBoardTemplate;
