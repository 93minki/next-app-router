import React from "react";

// props으로 grid컬럼 갯수,  내용 전달받기

type Props = {
  // grid: "1" | "2" | "3" | "4" | "6";
  grid: string;
  children: React.ReactNode;
};

export default function GridLow({ grid: count, children }: Props) {
  const style = `grid grid-cols-${count}`;
  return <div className={`grid grid-cols-${count}`}>{children}</div>;
}
