"use client";

const Avatar = () => {
  return <div className={"rounded-full w-8 h-8 bg-cyan-400"}></div>;
};

export default Avatar;
