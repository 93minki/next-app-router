import Link from "next/link";

export default function Home() {
  return (
    <main className=" w-full h-screen text-center leading-[100vh]">
      <Link href="/dashboard">Click to move Dashboard!</Link>
    </main>
  );
}
