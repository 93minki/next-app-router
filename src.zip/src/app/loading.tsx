export default function Loading() {
  return "Loading...";
}
